# flipper-zero-customs-docs
Ready documents/procedures for successfully passing customs clearance in your country

List of countries, covered with customs docs:

1. UKRAINE
2. IN PROGRESS OTHER COUNTRIES 

If you have such experience feel free to create PR with instructions for your Country. Also you can attach yor donation box. 